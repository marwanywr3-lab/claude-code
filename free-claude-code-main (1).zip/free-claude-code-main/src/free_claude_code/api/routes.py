"""FastAPI route handlers."""

from collections.abc import Mapping
from typing import Annotated, Any, cast

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from loguru import logger
from pydantic import ValidationError

from free_claude_code.application.errors import ApplicationError, InvalidRequestError
from free_claude_code.application.ports import ProviderResolver, RequestRuntimeLease
from free_claude_code.application.routing import ModelRouter, supports_native_messages
from free_claude_code.config.model_refs import parse_provider_type
from free_claude_code.config.settings import Settings
from free_claude_code.core.anthropic import (
    MessagesRequest,
    NativeTokenCountRequest,
    TokenCountRequest,
    get_token_count,
)
from free_claude_code.core.anthropic.native import (
    NativeMessagesError,
    validate_messages_json,
)
from free_claude_code.core.anthropic.passthrough import NativeMessagesRequest
from free_claude_code.core.json_types import JsonObject
from free_claude_code.core.openai_responses import OpenAIResponsesRequest
from free_claude_code.core.trace import trace_event

from .dependencies import (
    get_services,
    get_settings,
    require_anthropic_proxy_auth,
    require_proxy_auth,
    resolve_provider,
)
from .handlers import MessagesHandler, ResponsesHandler, TokenCountHandler
from .model_catalog import (
    ModelCatalogView,
    ModelsListResponse,
    build_models_list_response,
    build_muse_models_list_response,
)
from .ports import ApiServices
from .request_errors import ordinary_application_error_response
from .request_ids import get_request_id
from .response_streams import bind_response_lifetime

router = APIRouter()


def _provider_resolver(lease: RequestRuntimeLease) -> ProviderResolver:
    return lambda provider_type, api_key_number: resolve_provider(
        provider_type, api_key_number, lease=lease
    )


async def _create_messages_response(
    services: ApiServices,
    request_data: MessagesRequest | JsonObject,
    *,
    request_id: str,
    request_headers: Mapping[str, str] | None = None,
) -> object:
    lease: RequestRuntimeLease | None = None
    try:
        lease = await services.requests.acquire()
        router = ModelRouter(lease.settings)
        raw = (
            request_data.model_dump(mode="json", exclude_unset=True)
            if isinstance(request_data, MessagesRequest)
            else request_data
        )
        model = raw.get("model")
        resolved = (
            router.resolve(model) if isinstance(model, str) and model.strip() else None
        )
        native = resolved is not None and supports_native_messages(
            resolved.primary.provider_id
        )
        if native:
            try:
                native_request = NativeMessagesRequest(raw)
            except NativeMessagesError as error:
                raise InvalidRequestError(str(error)) from error
        else:
            if not isinstance(request_data, MessagesRequest):
                try:
                    request_data = MessagesRequest.model_validate(raw)
                except ValidationError as error:
                    raise RequestValidationError(
                        [
                            {**item, "loc": ("body", *item["loc"])}
                            for item in error.errors()
                        ],
                        body=raw,
                    ) from error
            await lease.wait_for_token_estimation()
        handler = MessagesHandler(
            lease.settings,
            web_tools=services.web_tools,
            provider_resolver=_provider_resolver(lease),
            token_counter=get_token_count,
            generation_id=lease.generation_id,
            request_headers=request_headers,
            model_info_lookup=lease.model_info,
        )
        if native:
            assert resolved is not None
            response = await handler.create_native(
                router.route_native_messages(native_request, resolved),
                request_id=request_id,
            )
        else:
            assert isinstance(request_data, MessagesRequest)
            response = await handler.create(request_data, request_id=request_id)
    except ApplicationError as exc:
        if lease is not None:
            await lease.release()
        return ordinary_application_error_response(
            exc,
            wire_api="messages",
            request_id=request_id,
        )
    except BaseException:
        if lease is not None:
            await lease.release()
        raise
    assert lease is not None
    return await bind_response_lifetime(response, lease.release)


async def _create_responses_response(
    services: ApiServices,
    request_data: OpenAIResponsesRequest,
    *,
    request_id: str,
    request_headers: Mapping[str, str] | None = None,
) -> object:
    lease: RequestRuntimeLease | None = None
    try:
        lease = await services.requests.acquire()
        await lease.wait_for_token_estimation()
        handler = ResponsesHandler(
            lease.settings,
            provider_resolver=_provider_resolver(lease),
            generation_id=lease.generation_id,
            request_headers=request_headers,
            model_info_lookup=lease.model_info,
        )
        response = await handler.create(request_data, request_id=request_id)
    except ApplicationError as exc:
        if lease is not None:
            await lease.release()
        return ordinary_application_error_response(
            exc,
            wire_api="responses",
            request_id=request_id,
        )
    except BaseException:
        if lease is not None:
            await lease.release()
        raise
    assert lease is not None
    return await bind_response_lifetime(response, lease.release)


def _probe_response(allow: str) -> Response:
    return Response(status_code=204, headers={"Allow": allow})


@router.post("/v1/messages")
async def create_message(
    request: Request,
    request_data: Annotated[dict[str, Any], Body()],
    services: ApiServices = Depends(get_services),
    _auth=Depends(require_anthropic_proxy_auth),
):
    """Create a message (JSON by default; stream=true returns Anthropic SSE)."""
    return await _create_messages_response(
        services,
        cast(JsonObject, request_data),
        request_id=get_request_id(request),
        request_headers=request.headers,
    )


@router.api_route("/v1/messages", methods=["HEAD", "OPTIONS"])
async def probe_messages(_auth=Depends(require_anthropic_proxy_auth)):
    return _probe_response("POST, HEAD, OPTIONS")


@router.post("/v1/responses")
async def create_response(
    request: Request,
    request_data: OpenAIResponsesRequest,
    services: ApiServices = Depends(get_services),
    _auth=Depends(require_proxy_auth),
):
    """Create an OpenAI Responses-compatible response through this proxy."""
    return await _create_responses_response(
        services,
        request_data,
        request_id=get_request_id(request),
        request_headers=request.headers,
    )


@router.api_route("/v1/responses", methods=["HEAD", "OPTIONS"])
async def probe_responses(_auth=Depends(require_proxy_auth)):
    return _probe_response("POST, HEAD, OPTIONS")


@router.post("/v1/messages/count_tokens")
async def count_tokens(
    request: Request,
    request_data: Annotated[dict[str, Any], Body()],
    services: ApiServices = Depends(get_services),
    _auth=Depends(require_anthropic_proxy_auth),
):
    """Count tokens for a request."""
    lease = await services.requests.acquire()
    try:
        model_router = ModelRouter(lease.settings)
        model = request_data.get("model")
        if isinstance(model, str) and not model.strip():
            raise InvalidRequestError("Messages model must not be empty.")
        resolved = (
            model_router.resolve(model)
            if isinstance(model, str) and model.strip()
            else None
        )
        try:
            if resolved is not None and supports_native_messages(
                resolved.primary.provider_id
            ):
                validate_messages_json(request_data)
                counted = NativeTokenCountRequest.model_validate(request_data)
            else:
                counted = TokenCountRequest.model_validate(request_data)
        except NativeMessagesError as error:
            raise InvalidRequestError(str(error)) from error
        except ValidationError as error:
            raise RequestValidationError(
                [{**item, "loc": ("body", *item["loc"])} for item in error.errors()],
                body=request_data,
            ) from error
        await lease.wait_for_token_estimation()
        handler = TokenCountHandler(
            lease.settings, model_router=model_router, token_counter=get_token_count
        )
        return handler.count(
            counted, request_id=get_request_id(request), resolved=resolved
        )
    finally:
        await lease.release()


@router.api_route("/v1/messages/count_tokens", methods=["HEAD", "OPTIONS"])
async def probe_count_tokens(_auth=Depends(require_anthropic_proxy_auth)):
    return _probe_response("POST, HEAD, OPTIONS")


@router.get("/")
async def root(
    settings: Settings = Depends(get_settings),
    _auth=Depends(require_proxy_auth),
):
    return {
        "status": "ok",
        "provider": parse_provider_type(settings.model),
        "model": settings.model,
    }


@router.api_route("/", methods=["HEAD", "OPTIONS"])
async def probe_root():
    return _probe_response("GET, HEAD, OPTIONS")


@router.get("/health")
async def health():
    return {"status": "healthy"}


@router.api_route("/health", methods=["HEAD", "OPTIONS"])
async def probe_health():
    return _probe_response("GET, HEAD, OPTIONS")


@router.get(
    "/v1/models",
    response_model=ModelsListResponse,
    response_model_exclude_none=True,
)
async def list_models(
    view: ModelCatalogView | None = None,
    x_fcc_model_view: ModelCatalogView | None = Header(default=None),
    services: ApiServices = Depends(get_services),
    _auth=Depends(require_proxy_auth),
):
    """List the model ids this proxy advertises to compatible clients."""
    trace_event(stage="ingress", event="free_claude_code.api.models.list", source="api")
    snapshot = await services.requests.wait_for_catalog()
    return build_models_list_response(
        snapshot.settings,
        snapshot,
        view=view or x_fcc_model_view or ModelCatalogView.CLAUDE,
    )


@router.get(
    "/muse-code/models",
    response_model=ModelsListResponse,
    response_model_exclude_none=True,
)
async def list_muse_models(
    services: ApiServices = Depends(get_services),
    _auth=Depends(require_proxy_auth),
):
    """List the direct Responses models expected by Muse Code."""
    trace_event(stage="ingress", event="free_claude_code.api.models.list", source="api")
    snapshot = await services.requests.wait_for_catalog()
    return build_muse_models_list_response(snapshot.settings, snapshot)


@router.post("/stop")
async def stop_cli(
    services: ApiServices = Depends(get_services),
    _auth=Depends(require_proxy_auth),
):
    """Stop all CLI sessions and pending tasks."""
    result = await services.tasks.stop_all()
    if result is None:
        raise HTTPException(status_code=503, detail="Messaging system not initialized")
    if result.source is not None:
        logger.info("STOP_CLI: source={} cancelled_count=N/A", result.source)
        return {"status": "stopped", "source": result.source}

    count = result.cancelled_count or 0
    trace_event(
        stage="ingress",
        event="free_claude_code.api.cli.stop_via_messaging_workflow",
        source="api",
        cancelled_nodes=count,
    )
    logger.info("STOP_CLI: source=messaging_workflow cancelled_count={}", count)
    return {"status": "stopped", "cancelled_count": count}
